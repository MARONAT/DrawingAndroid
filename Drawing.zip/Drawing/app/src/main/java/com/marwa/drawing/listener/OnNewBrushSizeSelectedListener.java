package com.marwa.drawing.listener;

public interface OnNewBrushSizeSelectedListener {
    void OnNewBrushSizeSelected(float newBrushSize);
}
